function doGet() {
  return HtmlService.createHtmlOutputFromFile('attendanceForm').setTitle('Student Attendance System');
}

// Fetch teacher list from Sheet2
function getTeacherList() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sheet2');
  const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
  return data.flat();
}

// Record attendance in Sheet1
function recordAttendance(name, type, location, photoBase64) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Sheet1');
  const now = new Date();
  const lastRow = sheet.getLastRow() + 1;

  let photoUrl = '';
  if (photoBase64) {
    photoUrl = savePhotoToDrive(photoBase64, name, now);
  }

  if (type === 'check-in') {
    sheet.getRange(lastRow, 1).setValue(name);
    sheet.getRange(lastRow, 2).setValue(now);
    sheet.getRange(lastRow, 4).setValue(location);
    sheet.getRange(lastRow, 7).setValue(photoUrl);
  } else if (type === 'check-out') {
    const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 7).getValues();
    for (let i = data.length - 1; i >= 0; i--) {
      if (data[i][0] === name && !data[i][2]) {
        const entryTime = new Date(data[i][1]);
        sheet.getRange(i + 2, 3).setValue(now); // Leaving time
        sheet.getRange(i + 2, 5).setValue(location); // Leaving location

        const duration = ((now - entryTime) / 60000).toFixed(2);
        sheet.getRange(i + 2, 6).setValue(duration); // Duration
        break;
      }
    }
  }
}

// Helper Function: Save Photo to Google Drive
function savePhotoToDrive(photoBase64, name, timestamp) {
  const folder = DriveApp.getFolderById('1Mr44tssSrgiqBTC8WKzurXOo6K8sGdDi'); // Replace with your folder ID
  const decoded = Utilities.base64Decode(photoBase64.split(',')[1]);
  const blob = Utilities.newBlob(decoded, 'image/png', `${name}-${timestamp}.png`);
  const file = folder.createFile(blob);
  return file.getUrl(); // Shareable URL for the photo
}
